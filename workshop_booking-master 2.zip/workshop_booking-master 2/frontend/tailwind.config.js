export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        primary: '#0F6E56',
        surface: '#E1F5EE',
        textPrimary: '#1A1A1A',
        textSecondary: '#6B7280',
        success: '#16A34A',
        warning: '#F59E0B',
        error: '#DC2626',
      },
      fontFamily: {
        sora: ['Sora', 'sans-serif'],
        sans: ['DM Sans', 'sans-serif'], // Body font as default
      },
      spacing: {
        // base 8px is naturally handled by Tailwind (1 = 0.25rem = 4px, 2 = 8px)
      },
      borderRadius: {
        '2xl': '16px', // Cards
        'xl': '12px', // Inputs/Buttons
      },
      boxShadow: {
        'soft': '0 4px 20px -2px rgba(0, 0, 0, 0.05)',
      }
    },
  },
  plugins: [],
}
