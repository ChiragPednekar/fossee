export const WORKSHOPS = [
  {
    id: "1",
    title: "Intro to React",
    date: "2024-05-15T10:00:00Z",
    location: "Tech Hub, Room A",
    instructor: "Jane Doe",
    status: "upcoming",
    description: "Learn the basics of React, components, and state management in this intensive 3-hour workshop."
  },
  {
    id: "2",
    title: "Advanced Tailwind CSS",
    date: "2024-05-20T14:00:00Z",
    location: "Design Center",
    instructor: "John Smith",
    status: "upcoming",
    description: "Master utility-first CSS and building your own design systems."
  },
  {
    id: "3",
    title: "Node API Design",
    date: "2024-04-10T09:00:00Z",
    location: "Online",
    instructor: "Alice Johnson",
    status: "completed",
    description: "Best practices for building scalable RESTful APIs with Node.js."
  },
  {
    id: "4",
    title: "Figma Prototyping",
    date: "2024-03-05T13:00:00Z",
    location: "Creative Lab",
    instructor: "Mark Lee",
    status: "completed",
    description: "Deep dive into interactive prototyping and animations in Figma."
  },
  {
    id: "5",
    title: "Docker Essentials",
    date: "2024-06-01T10:00:00Z",
    location: "Online",
    instructor: "Sam Perez",
    status: "pending",
    description: "Containerize your applications easily using Docker."
  },
  {
    id: "6",
    title: "GraphQL APIs",
    date: "2024-02-15T10:00:00Z",
    location: "Tech Hub, Room B",
    instructor: "Jane Doe",
    status: "cancelled",
    description: "Build robust APIs with GraphQL."
  }
];

export const USER_STATS = {
  upcoming: 2,
  attended: 2,
  pending: 1,
  cancelled: 1,
};
