import React from 'react';
import { Header } from './Header';
import { TabBar } from './TabBar';
import { useLocation } from 'react-router-dom';

export default function Layout({ children }) {
  const location = useLocation();
  const isAuthPage = location.pathname.includes('/auth'); // Hide layout on auth

  if (isAuthPage) {
    return <div className="min-h-screen bg-gray-50">{children}</div>;
  }

  return (
    <div className="min-h-screen bg-gray-50 pb-20"> {/* pb-20 for bottom tab bar */}
      <Header />
      <main className="mx-auto max-w-md w-full animate-in fade-in duration-300">
        {children}
      </main>
      <TabBar />
    </div>
  );
}
