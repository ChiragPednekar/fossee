import React, { useState } from 'react';
import { Menu, X } from 'lucide-react';
import { cn } from '../../lib/utils';
import { Link } from 'react-router-dom';

export function Header() {
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 w-full bg-white/80 backdrop-blur-md border-b border-gray-100">
      <div className="flex h-16 items-center justify-between px-4 sm:px-6">
        <div className="flex items-center gap-3">
          <div className="h-10 w-10 overflow-hidden rounded-full bg-surface border-2 border-primary">
            <img 
              src="https://api.dicebear.com/7.x/avataaars/svg?seed=Felix" 
              alt="User Avatar"
              className="h-full w-full object-cover"
            />
          </div>
          <div className="flex flex-col">
            <span className="text-xs text-textSecondary font-medium">Welcome back,</span>
            <span className="font-sora text-sm font-semibold text-textPrimary">Alex User</span>
          </div>
        </div>
        
        <button 
          onClick={() => setMenuOpen(!menuOpen)}
          className="rounded-full p-2 hover:bg-gray-100 active:bg-gray-200"
        >
          {menuOpen ? <X size={24} className="text-textPrimary" /> : <Menu size={24} className="text-textPrimary" />}
        </button>
      </div>

      {/* Dropdown Menu */}
      {menuOpen && (
        <div className="absolute top-16 right-4 z-50 w-48 rounded-2xl bg-white p-2 shadow-xl border border-gray-100 origin-top-right animate-in fade-in slide-in-from-top-2">
          <div className="flex flex-col space-y-1">
            <Link to="/profile" className="rounded-xl px-4 py-3 text-sm font-medium text-textPrimary hover:bg-surface active:bg-surface/80 transition-colors" onClick={() => setMenuOpen(false)}>
              Profile
            </Link>
            <button className="rounded-xl px-4 py-3 text-left text-sm font-medium text-textPrimary hover:bg-surface active:bg-surface/80 transition-colors" onClick={() => setMenuOpen(false)}>
              Help & Support
            </button>
            <div className="my-1 h-px bg-gray-100" />
            <button className="rounded-xl px-4 py-3 text-left text-sm font-medium text-error hover:bg-red-50 active:bg-red-100 transition-colors" onClick={() => setMenuOpen(false)}>
              Logout
            </button>
          </div>
        </div>
      )}
    </header>
  );
}
