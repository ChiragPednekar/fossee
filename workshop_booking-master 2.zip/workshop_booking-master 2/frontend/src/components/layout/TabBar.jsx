import React from 'react';
import { NavLink } from 'react-router-dom';
import { Home, Compass, CalendarCheck, User } from 'lucide-react';
import { cn } from '../../lib/utils';

export function TabBar() {
  const navItems = [
    { name: 'Home', path: '/', icon: Home },
    { name: 'Browse', path: '/browse', icon: Compass },
    { name: 'Bookings', path: '/bookings', icon: CalendarCheck },
    { name: 'Profile', path: '/profile', icon: User },
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 z-40 border-t border-gray-100 bg-white pb-safe">
      <nav className="flex h-16 items-center justify-around px-2">
        {navItems.map((item) => {
          const Icon = item.icon;
          return (
            <NavLink
              key={item.path}
              to={item.path}
              className={({ isActive }) =>
                cn(
                  "flex flex-col items-center justify-center w-16 h-full space-y-1 rounded-xl transition-colors active:bg-surface/50",
                  isActive ? "text-primary" : "text-textSecondary hover:text-textPrimary"
                )
              }
            >
              {({ isActive }) => (
                <>
                  <Icon size={24} className={isActive ? "fill-primary/20" : ""} />
                  <span className={cn("text-[10px] font-medium leading-none", isActive && "font-semibold")}>
                    {item.name}
                  </span>
                </>
              )}
            </NavLink>
          );
        })}
      </nav>
    </div>
  );
}
