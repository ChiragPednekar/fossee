import React from 'react';
import { cn } from '../../lib/utils';

export function ProgressBar({ currentStep, totalSteps, className }) {
  return (
    <div className={cn("w-full space-y-2", className)}>
      <div className="flex justify-between text-xs font-medium text-textSecondary px-1">
        <span>Step {currentStep} of {totalSteps}</span>
      </div>
      <div className="h-2 w-full overflow-hidden rounded-full bg-surface">
        <div 
          className="h-full bg-primary transition-all duration-300 ease-out"
          style={{ width: `${(currentStep / totalSteps) * 100}%` }}
        />
      </div>
    </div>
  );
}
