import React from 'react';
import { cn } from '../../lib/utils';

export function Card({ className, ...props }) {
  return (
    <div className={cn("rounded-2xl border border-gray-100 bg-white shadow-soft", className)} {...props} />
  );
}

export function CardHeader({ className, ...props }) {
  return <div className={cn("flex flex-col space-y-1.5 p-4 sm:p-6", className)} {...props} />;
}

export function CardTitle({ className, ...props }) {
  return <h3 className={cn("font-sora text-lg font-semibold leading-none tracking-tight text-textPrimary", className)} {...props} />;
}

export function CardContent({ className, ...props }) {
  return <div className={cn("p-4 sm:p-6 pt-0 text-textSecondary", className)} {...props} />;
}

export function CardFooter({ className, ...props }) {
  return <div className={cn("flex items-center p-4 sm:p-6 pt-0", className)} {...props} />;
}
