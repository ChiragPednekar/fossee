import React, { useEffect } from 'react';
import { cn } from '../../lib/utils';
import { X } from 'lucide-react';

export function BottomSheet({ isOpen, onClose, children, title }) {
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'auto';
    }
    return () => {
      document.body.style.overflow = 'auto';
    };
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex flex-col justify-end">
      <div 
        className="fixed inset-0 bg-black/40 transition-opacity" 
        onClick={onClose}
        aria-hidden="true"
      />
      <div 
        className="relative z-50 flex h-auto max-h-[90vh] w-full flex-col overflow-hidden rounded-t-[20px] bg-white shadow-xl translate-y-0 transition-transform duration-300 ease-out"
      >
        <div className="flex h-14 items-center justify-between border-b border-gray-100 px-4">
          <h2 className="font-sora text-lg font-semibold text-textPrimary">{title}</h2>
          <button 
            onClick={onClose}
            className="rounded-full p-2 hover:bg-gray-100 active:bg-gray-200 transition-colors"
          >
            <X size={20} className="text-textSecondary" />
          </button>
        </div>
        <div className="flex-1 overflow-y-auto px-4 py-6">
          {children}
        </div>
      </div>
    </div>
  );
}
