import React from 'react';
import { cn } from '../../lib/utils';

export function Badge({ className, variant = 'default', children, ...props }) {
  const variants = {
    default: "bg-surface text-primary",
    success: "bg-green-100 text-success",
    warning: "bg-yellow-100 text-warning",
    error: "bg-red-100 text-error",
    upcoming: "bg-blue-100 text-blue-700",
    completed: "bg-green-100 text-success",
    pending: "bg-yellow-100 text-warning",
    cancelled: "bg-red-100 text-error",
  };

  return (
    <div
      className={cn(
        "inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold capitalize",
        variants[variant],
        className
      )}
      {...props}
    >
      {children}
    </div>
  );
}
