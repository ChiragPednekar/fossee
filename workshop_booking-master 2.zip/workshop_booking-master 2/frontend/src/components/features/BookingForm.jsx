import React, { useState } from 'react';
import { ProgressBar } from '../ui/ProgressBar';
import Input from '../ui/Input';
import Button from '../ui/Button';

export function BookingForm({ workshop, onComplete }) {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    college: '',
    date: workshop?.date?.split('T')[0] || ''
  });
  const [errors, setErrors] = useState({});

  const validateStep1 = () => {
    let newErrors = {};
    if (!formData.name) newErrors.name = "Name is required";
    if (!formData.email || !/\S+@\S+\.\S+/.test(formData.email)) newErrors.email = "Valid email is required";
    if (!formData.phone) newErrors.phone = "Phone is required";
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const validateStep2 = () => {
    let newErrors = {};
    if (!formData.college) newErrors.college = "College name is required";
    if (!formData.date) newErrors.date = "Date is required";
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleNext = () => {
    if (step === 1 && validateStep1()) setStep(2);
    else if (step === 2 && validateStep2()) setStep(3);
  };

  const handleSubmit = () => {
    // Simulate API call
    setTimeout(() => {
      onComplete();
    }, 800);
  };

  return (
    <div className="flex flex-col h-full space-y-6">
      <ProgressBar currentStep={step} totalSteps={3} />
      
      <div className="flex-1 overflow-y-auto w-full no-scrollbar px-1 pb-4">
        {step === 1 && (
          <div className="animate-in fade-in slide-in-from-right-4 space-y-4">
            <h3 className="font-sora text-lg font-semibold text-textPrimary mb-4">Personal Info</h3>
            <Input 
              label="Full Name" 
              placeholder="John Doe" 
              value={formData.name}
              onChange={e => setFormData({...formData, name: e.target.value})}
              error={errors.name}
            />
            <Input 
              label="Email Address" 
              type="email" 
              placeholder="john@example.com" 
              value={formData.email}
              onChange={e => setFormData({...formData, email: e.target.value})}
              error={errors.email}
            />
            <Input 
              label="Phone Number" 
              type="tel" 
              placeholder="+1 234 567 890" 
              value={formData.phone}
              onChange={e => setFormData({...formData, phone: e.target.value})}
              error={errors.phone}
            />
          </div>
        )}

        {step === 2 && (
          <div className="animate-in fade-in slide-in-from-right-4 space-y-4">
            <h3 className="font-sora text-lg font-semibold text-textPrimary mb-4">Education Details</h3>
            <Input 
              label="College Name" 
              placeholder="University of Technology" 
              value={formData.college}
              onChange={e => setFormData({...formData, college: e.target.value})}
              error={errors.college}
            />
            <Input 
              label="Selected Date" 
              type="date" 
              value={formData.date}
              onChange={e => setFormData({...formData, date: e.target.value})}
              error={errors.date}
            />
          </div>
        )}

        {step === 3 && (
          <div className="animate-in fade-in slide-in-from-right-4 space-y-4">
            <div className="rounded-2xl bg-surface/50 p-6 flex flex-col items-center justify-center text-center space-y-3">
              <span className="text-4xl">🎉</span>
              <h3 className="font-sora text-lg font-semibold text-textPrimary">Review & Confirm</h3>
            </div>
            
            <div className="bg-white rounded-xl border border-gray-100 p-4 space-y-3 shadow-sm">
              <div className="flex justify-between border-b border-gray-50 pb-2">
                <span className="text-sm text-textSecondary">Workshop</span>
                <span className="text-sm font-medium text-textPrimary text-right">{workshop.title}</span>
              </div>
              <div className="flex justify-between border-b border-gray-50 pb-2">
                <span className="text-sm text-textSecondary">Name</span>
                <span className="text-sm font-medium text-textPrimary text-right">{formData.name}</span>
              </div>
              <div className="flex justify-between border-b border-gray-50 pb-2">
                <span className="text-sm text-textSecondary">Email</span>
                <span className="text-sm font-medium text-textPrimary text-right">{formData.email}</span>
              </div>
              <div className="flex justify-between border-b border-gray-50 pb-2">
                <span className="text-sm text-textSecondary">College</span>
                <span className="text-sm font-medium text-textPrimary text-right">{formData.college}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-textSecondary">Date</span>
                <span className="text-sm font-medium text-textPrimary text-right">{formData.date}</span>
              </div>
            </div>
          </div>
        )}
      </div>

      <div className="mt-auto pt-4 flex gap-3">
        {step > 1 && (
          <Button variant="outline" className="w-1/3" onClick={() => setStep(step - 1)}>
            Back
          </Button>
        )}
        {step < 3 ? (
          <Button className="flex-1" onClick={handleNext}>
            Continue
          </Button>
        ) : (
          <Button className="flex-1" onClick={handleSubmit}>
            Confirm Booking
          </Button>
        )}
      </div>
    </div>
  );
}
