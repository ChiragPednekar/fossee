import React, { useState } from 'react';
import Input from '../components/ui/Input';
import Button from '../components/ui/Button';
import { Eye, EyeOff, BookOpenCheck } from 'lucide-react';

export default function Auth() {
  const [isLogin, setIsLogin] = useState(true);
  const [showPassword, setShowPassword] = useState(false);
  
  const handleAuth = (e) => {
    e.preventDefault();
    window.location.reload(); // Simple reload will bypass auth based on App.jsx state
  };

  return (
    <div className="flex flex-col min-h-screen bg-white">
      <div className="flex-1 flex flex-col justify-center px-6 py-12 lg:px-8 max-w-md mx-auto w-full animate-in fade-in slide-in-from-bottom-4 duration-500">
        
        <div className="sm:mx-auto sm:w-full sm:max-w-sm mb-10 text-center">
          <div className="mx-auto w-16 h-16 bg-surface rounded-2xl flex items-center justify-center mb-6 shadow-sm border border-primary/10">
            <BookOpenCheck size={32} className="text-primary" />
          </div>
          <h2 className="text-3xl font-bold font-sora tracking-tight text-textPrimary">
            {isLogin ? "Welcome back" : "Create an account"}
          </h2>
          <p className="mt-2 text-sm text-textSecondary">
            {isLogin ? "Enter your details to access your workshops" : "Sign up to start booking workshops today"}
          </p>
        </div>

        <div className="sm:mx-auto sm:w-full sm:max-w-sm space-y-6">
          <Button 
            className="w-full relative bg-white border border-gray-200 text-textPrimary hover:bg-gray-50 focus:ring-gray-200 h-12 rounded-xl flex items-center justify-center shadow-sm"
          >
            <svg className="h-5 w-5 mr-3" viewBox="0 0 24 24">
              <path
                d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                fill="#4285F4"
              />
              <path
                d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                fill="#34A853"
              />
              <path
                d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
                fill="#FBBC05"
              />
              <path
                d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
                fill="#EA4335"
              />
            </svg>
            <span className="font-medium">Continue with Google</span>
          </Button>

          <div className="relative">
            <div className="absolute inset-0 flex items-center" aria-hidden="true">
              <div className="w-full border-t border-gray-200" />
            </div>
            <div className="relative flex justify-center text-sm font-medium leading-6">
              <span className="bg-white px-4 text-textSecondary">Or continue with email</span>
            </div>
          </div>

          <form className="space-y-4" onSubmit={handleAuth}>
            {!isLogin && (
              <Input 
                id="name" 
                label="Full Name" 
                type="text" 
                autoComplete="name" 
                required 
                placeholder="John Doe"
              />
            )}
            
            <Input 
              id="email" 
              label="Email address" 
              type="email" 
              autoComplete="email" 
              required 
              placeholder="name@example.com"
            />

            <div className="relative">
              <Input 
                id="password" 
                label="Password" 
                type={showPassword ? "text" : "password"} 
                autoComplete="current-password" 
                required 
                placeholder="••••••••"
              />
              <button
                type="button"
                className="absolute right-3 top-[34px] text-gray-400 hover:text-gray-600 focus:outline-none"
                onClick={() => setShowPassword(!showPassword)}
              >
                {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
              </button>
            </div>

            {isLogin && (
              <div className="flex items-center justify-end">
                <div className="text-sm">
                  <a href="#" className="font-medium text-primary hover:text-primary/80">
                    Forgot password?
                  </a>
                </div>
              </div>
            )}

            <Button type="submit" className="w-full text-lg shadow-soft h-12 mt-2">
              {isLogin ? "Sign In" : "Create Account"}
            </Button>
          </form>

          <p className="mt-10 text-center text-sm text-textSecondary">
            {isLogin ? "Don't have an account? " : "Already have an account? "}
            <button 
              onClick={() => setIsLogin(!isLogin)}
              className="font-semibold text-primary hover:text-primary/80 transition-colors"
            >
              {isLogin ? "Sign up" : "Log in"}
            </button>
          </p>
        </div>
      </div>
    </div>
  );
}
