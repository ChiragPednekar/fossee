import React, { useState } from 'react';
import { WORKSHOPS } from '../data/mockData';
import { Card, CardContent } from '../components/ui/Card';
import { Badge } from '../components/ui/Badge';
import { BottomSheet } from '../components/ui/BottomSheet';
import Button from '../components/ui/Button';
import { BookingForm } from '../components/features/BookingForm';
import { Search, MapPin, Calendar, User, Clock, Filter } from 'lucide-react';

export default function Browse() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedWorkshop, setSelectedWorkshop] = useState(null);
  const [isBooking, setIsBooking] = useState(false);

  const filteredWorkshops = WORKSHOPS.filter(w => 
    w.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
    w.instructor.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleBookNow = () => {
    setIsBooking(true);
  };

  const handleBookingComplete = () => {
    setIsBooking(false);
    setSelectedWorkshop(null);
    alert("Booking Successful!"); // simple feedback for demo
  };

  return (
    <div className="p-4 sm:p-6 space-y-6">
      <div className="space-y-4">
        <h1 className="font-sora text-2xl font-bold text-textPrimary">Discover</h1>
        
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-textSecondary" size={20} />
          <input 
            type="text" 
            placeholder="Search workshops..." 
            className="w-full h-12 pl-10 pr-4 rounded-xl border border-gray-200 bg-white focus:outline-none focus:ring-2 focus:ring-primary shadow-sm"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>

        <div className="flex gap-2 overflow-x-auto no-scrollbar pb-2">
          {['All', 'Development', 'Design', 'Marketing', 'Business'].map(cat => (
            <button key={cat} className="px-4 py-2 rounded-full whitespace-nowrap text-sm font-medium border border-gray-100 bg-white text-textSecondary hover:bg-surface hover:text-primary transition-colors">
              {cat}
            </button>
          ))}
        </div>
      </div>

      <div className="space-y-4">
        <div className="flex justify-between items-center mb-2 px-1">
          <span className="text-sm font-medium text-textSecondary">{filteredWorkshops.length} results found</span>
          <button className="text-primary p-2 -mr-2"><Filter size={18} /></button>
        </div>
        
        {filteredWorkshops.map(workshop => (
          <Card 
            key={workshop.id} 
            className="cursor-pointer hover:shadow-md transition-shadow active:scale-[0.98]"
            onClick={() => { setSelectedWorkshop(workshop); setIsBooking(false); }}
          >
            <CardContent className="p-5 flex flex-col gap-3">
              <div className="flex justify-between items-start gap-4">
                <h3 className="font-sora font-semibold text-lg text-textPrimary">{workshop.title}</h3>
                <Badge variant={workshop.status}>{workshop.status}</Badge>
              </div>
              
              <div className="grid grid-cols-2 gap-y-2 mt-2">
                <div className="flex items-center text-xs text-textSecondary">
                  <Calendar size={14} className="mr-1.5 text-primary" />
                  {new Date(workshop.date).toLocaleDateString()}
                </div>
                <div className="flex items-center text-xs text-textSecondary">
                  <Clock size={14} className="mr-1.5 text-primary" />
                  {new Date(workshop.date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </div>
                <div className="flex items-center text-xs text-textSecondary col-span-2">
                  <MapPin size={14} className="mr-1.5 text-primary" />
                  {workshop.location}
                </div>
                <div className="flex items-center text-xs text-textSecondary col-span-2">
                  <User size={14} className="mr-1.5 text-primary" />
                  Instructor: {workshop.instructor}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
        {filteredWorkshops.length === 0 && (
           <div className="text-center py-10 text-textSecondary">No workshops found.</div>
        )}
      </div>

      <BottomSheet 
        isOpen={!!selectedWorkshop} 
        onClose={() => {
          setSelectedWorkshop(null);
          setIsBooking(false);
        }}
        title={isBooking ? "Secure Booking" : "Workshop Details"}
      >
        {selectedWorkshop && !isBooking && (
          <div className="flex flex-col h-full space-y-6">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <Badge variant={selectedWorkshop.status} className="text-sm px-3 py-1">{selectedWorkshop.status}</Badge>
              </div>
              
              <h2 className="font-sora text-2xl font-bold text-textPrimary leading-tight">
                {selectedWorkshop.title}
              </h2>
              
              <p className="text-textSecondary leading-relaxed">
                {selectedWorkshop.description}
              </p>
            </div>

            <div className="bg-surface/30 rounded-2xl p-4 space-y-4 border border-surface">
              <div className="flex items-center text-sm font-medium text-textPrimary">
                <div className="w-10 h-10 rounded-full bg-white flex items-center justify-center mr-3 text-primary shadow-sm">
                  <Calendar size={20} />
                </div>
                <div className="flex flex-col">
                  <span>{new Date(selectedWorkshop.date).toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' })}</span>
                  <span className="text-xs text-textSecondary">{new Date(selectedWorkshop.date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                </div>
              </div>
              
              <div className="flex items-center text-sm font-medium text-textPrimary">
                <div className="w-10 h-10 rounded-full bg-white flex items-center justify-center mr-3 text-primary shadow-sm">
                  <MapPin size={20} />
                </div>
                <div className="flex flex-col">
                  <span>Location</span>
                  <span className="text-xs text-textSecondary">{selectedWorkshop.location}</span>
                </div>
              </div>

              <div className="flex items-center text-sm font-medium text-textPrimary">
                <div className="w-10 h-10 rounded-full bg-white flex items-center justify-center mr-3 text-primary shadow-sm">
                  <User size={20} />
                </div>
                <div className="flex flex-col">
                  <span>Instructor</span>
                  <span className="text-xs text-textSecondary">{selectedWorkshop.instructor}</span>
                </div>
              </div>
            </div>

            <div className="mt-8 pt-4 border-t border-gray-100 flex sticky bottom-0 bg-white pb-4">
              <Button className="w-full" size="lg" onClick={handleBookNow}>
                Book Now
              </Button>
            </div>
          </div>
        )}

        {selectedWorkshop && isBooking && (
          <BookingForm 
            workshop={selectedWorkshop} 
            onComplete={handleBookingComplete} 
          />
        )}
      </BottomSheet>
    </div>
  );
}
