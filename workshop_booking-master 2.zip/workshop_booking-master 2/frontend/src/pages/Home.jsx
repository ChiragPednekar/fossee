import React from 'react';
import { Card, CardContent } from '../components/ui/Card';
import { Badge } from '../components/ui/Badge';
import { USER_STATS, WORKSHOPS } from '../data/mockData';
import { MapPin, Calendar, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import { cn } from '../lib/utils';

export default function Home() {
  const upcomingWorkshops = WORKSHOPS.filter(w => w.status === 'upcoming').slice(0, 2);
  const pastWorkshops = WORKSHOPS.filter(w => w.status === 'completed').slice(0, 3);

  const StatChip = ({ label, value, colorClass }) => (
    <div className="flex flex-col items-center justify-center rounded-2xl bg-white p-3 shadow-sm border border-gray-100">
      <span className={cn("text-2xl font-sora font-semibold", colorClass)}>{value}</span>
      <span className="text-[10px] font-medium text-textSecondary uppercase tracking-wider mt-1">{label}</span>
    </div>
  );

  return (
    <div className="p-4 sm:p-6 space-y-8">
      {/* Stats Grid */}
      <section className="grid grid-cols-4 gap-2">
        <StatChip label="Upcoming" value={USER_STATS.upcoming} colorClass="text-blue-600" />
        <StatChip label="Attended" value={USER_STATS.attended} colorClass="text-success" />
        <StatChip label="Pending" value={USER_STATS.pending} colorClass="text-warning" />
        <StatChip label="Cancelled" value={USER_STATS.cancelled} colorClass="text-error" />
      </section>

      {/* Upcoming Workshops */}
      <section className="space-y-4">
        <div className="flex items-center justify-between px-1">
          <h2 className="font-sora text-lg font-semibold text-textPrimary">Upcoming Workshops</h2>
          <Link to="/browse" className="text-sm font-medium text-primary hover:text-primary/80 flex items-center">
            See all <ArrowRight size={16} className="ml-1" />
          </Link>
        </div>
        <div className="flex flex-col gap-3">
          {upcomingWorkshops.map(workshop => (
            <Card key={workshop.id} className="overflow-hidden active:scale-[0.98] transition-transform">
              <CardContent className="p-4">
                <div className="flex justify-between items-start mb-2">
                  <h3 className="font-sora font-semibold text-textPrimary text-base line-clamp-1">{workshop.title}</h3>
                  <Badge variant={workshop.status}>{workshop.status}</Badge>
                </div>
                <div className="space-y-1.5 mt-3">
                  <div className="flex items-center text-xs text-textSecondary">
                    <Calendar size={14} className="mr-2 text-primary" />
                    {new Date(workshop.date).toLocaleDateString(undefined, { weekday: 'short', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
                  </div>
                  <div className="flex items-center text-xs text-textSecondary">
                    <MapPin size={14} className="mr-2 text-primary" />
                    {workshop.location}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* Past Workshops Timeline */}
      <section className="space-y-4">
        <div className="px-1">
          <h2 className="font-sora text-lg font-semibold text-textPrimary">Past Workshops</h2>
        </div>
        <div className="relative pl-3 space-y-6 before:absolute before:inset-y-0 before:left-[15px] before:w-px before:bg-gray-200">
          {pastWorkshops.map(workshop => (
            <div key={workshop.id} className="relative flex items-start gap-4 pl-6">
              <div className="absolute left-[3px] top-1 h-2 w-2 rounded-full bg-gray-300 ring-4 ring-gray-50" />
              <div className="flex flex-col">
                <span className="text-xs font-semibold text-textSecondary uppercase tracking-wider">
                  {new Date(workshop.date).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}
                </span>
                <h4 className="text-sm font-medium text-textPrimary mt-0.5">{workshop.title}</h4>
                <span className="text-xs text-textSecondary mt-1">Instructor: {workshop.instructor}</span>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
