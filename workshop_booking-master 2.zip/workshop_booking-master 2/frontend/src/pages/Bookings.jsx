import React, { useState } from 'react';
import { WORKSHOPS } from '../data/mockData';
import { Card, CardContent } from '../components/ui/Card';
import { Badge } from '../components/ui/Badge';
import { Calendar, MapPin, Clock } from 'lucide-react';
import { cn } from '../lib/utils';

export default function Bookings() {
  const [activeTab, setActiveTab] = useState('upcoming');
  
  const upcomingBooks = WORKSHOPS.filter(w => w.status === 'upcoming' || w.status === 'pending');
  const pastBooks = WORKSHOPS.filter(w => w.status === 'completed' || w.status === 'cancelled');

  return (
    <div className="p-4 sm:p-6 space-y-6">
      <h1 className="font-sora text-2xl font-bold text-textPrimary">My Bookings</h1>
      
      {/* Tabs */}
      <div className="flex p-1 bg-gray-100 rounded-xl">
        <button 
          onClick={() => setActiveTab('upcoming')}
          className={cn(
            "flex-1 py-2.5 text-sm font-medium rounded-lg transition-all",
            activeTab === 'upcoming' ? "bg-white text-textPrimary shadow-sm" : "text-textSecondary hover:text-textPrimary"
          )}
        >
          Upcoming
        </button>
        <button 
          onClick={() => setActiveTab('past')}
          className={cn(
            "flex-1 py-2.5 text-sm font-medium rounded-lg transition-all",
            activeTab === 'past' ? "bg-white text-textPrimary shadow-sm" : "text-textSecondary hover:text-textPrimary"
          )}
        >
          Past
        </button>
      </div>

      <div className="mt-6 animate-in fade-in duration-200">
        {activeTab === 'upcoming' ? (
          <div className="space-y-4">
            {upcomingBooks.length === 0 ? (
              <div className="text-center py-10 text-textSecondary">You have no upcoming bookings.</div>
            ) : upcomingBooks.map(workshop => (
              <Card key={workshop.id} className="overflow-hidden">
                <CardContent className="p-4 bg-white">
                  <div className="flex justify-between items-start mb-3">
                    <h3 className="font-sora font-semibold text-textPrimary">{workshop.title}</h3>
                    <Badge variant={workshop.status}>{workshop.status}</Badge>
                  </div>
                  <div className="bg-surface/30 p-3 rounded-xl space-y-2 border border-surface/50">
                    <div className="flex justify-between items-center text-xs text-textSecondary">
                      <span className="flex items-center"><Calendar size={14} className="mr-1.5 text-primary"/> Date</span>
                      <span className="font-medium text-textPrimary">{new Date(workshop.date).toLocaleDateString()}</span>
                    </div>
                    <div className="flex justify-between items-center text-xs text-textSecondary">
                      <span className="flex items-center"><Clock size={14} className="mr-1.5 text-primary"/> Time</span>
                      <span className="font-medium text-textPrimary">{new Date(workshop.date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                    </div>
                    <div className="flex justify-between items-center text-xs text-textSecondary">
                      <span className="flex items-center"><MapPin size={14} className="mr-1.5 text-primary"/> Location</span>
                      <span className="font-medium text-textPrimary">{workshop.location}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <div className="relative pl-3 space-y-6 before:absolute before:inset-y-0 before:left-[15px] before:w-px before:bg-gray-200 py-2">
            {pastBooks.length === 0 ? (
              <div className="text-center py-10 text-textSecondary w-full">No past history.</div>
            ) : pastBooks.map(workshop => (
              <div key={workshop.id} className="relative flex items-start gap-4 pl-6 opacity-80 hover:opacity-100 transition-opacity">
                <div className="absolute left-[3px] top-1.5 h-2 w-2 rounded-full bg-gray-300 ring-4 ring-gray-50" />
                <div className="flex-1 bg-white border border-gray-100 rounded-xl p-3 shadow-sm">
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-xs font-semibold text-textSecondary uppercase tracking-wider">
                      {new Date(workshop.date).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' })}
                    </span>
                    <Badge variant={workshop.status} className="text-[10px] px-2 py-0">{workshop.status}</Badge>
                  </div>
                  <h4 className="text-sm font-medium text-textPrimary">{workshop.title}</h4>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
