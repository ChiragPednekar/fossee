import React from 'react';
import { Card, CardContent } from '../components/ui/Card';
import Button from '../components/ui/Button';
import { User, Mail, Phone, BookOpen, Settings, LogOut, ChevronRight } from 'lucide-react';

export default function Profile() {
  return (
    <div className="p-4 sm:p-6 space-y-6">
      <h1 className="font-sora text-2xl font-bold text-textPrimary">Profile</h1>
      
      <Card className="bg-gradient-to-br from-primary to-[#0A4A3A] text-white border-0 shadow-lg relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full blur-2xl -mr-10 -mt-10"></div>
        <div className="absolute bottom-0 left-0 w-24 h-24 bg-white/10 rounded-full blur-xl -ml-5 -mb-5"></div>
        
        <CardContent className="p-6 relative z-10 flex items-center space-x-5 text-white">
          <div className="h-20 w-20 rounded-full bg-white/20 border-2 border-white/50 overflow-hidden flex-shrink-0 backdrop-blur-sm">
            <img 
              src="https://api.dicebear.com/7.x/avataaars/svg?seed=Felix" 
              alt="User"
              className="h-full w-full object-cover"
            />
          </div>
          <div className="flex flex-col">
            <h2 className="font-sora text-xl font-bold">Alex User</h2>
            <p className="text-white/80 text-sm mt-0.5">Computer Science</p>
            <div className="flex items-center text-xs mt-2 text-white/90 bg-white/10 w-fit px-2.5 py-1 rounded-full backdrop-blur-sm">
              <BookOpen size={12} className="mr-1.5" />
              University of Technology
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="space-y-3">
        <h3 className="font-sora text-sm font-semibold text-textSecondary uppercase tracking-wider px-2">Account Info</h3>
        <Card>
          <CardContent className="p-0">
            <div className="flex items-center p-4 border-b border-gray-50">
              <div className="w-8 h-8 rounded-full bg-surface flex items-center justify-center mr-3">
                <User size={16} className="text-primary" />
              </div>
              <div className="flex-1">
                <p className="text-xs text-textSecondary">Full Name</p>
                <p className="text-sm font-medium text-textPrimary">Alex User</p>
              </div>
            </div>
            <div className="flex items-center p-4 border-b border-gray-50">
              <div className="w-8 h-8 rounded-full bg-surface flex items-center justify-center mr-3">
                <Mail size={16} className="text-primary" />
              </div>
              <div className="flex-1">
                <p className="text-xs text-textSecondary">Email Address</p>
                <p className="text-sm font-medium text-textPrimary">alex@example.com</p>
              </div>
            </div>
            <div className="flex items-center p-4">
              <div className="w-8 h-8 rounded-full bg-surface flex items-center justify-center mr-3">
                <Phone size={16} className="text-primary" />
              </div>
              <div className="flex-1">
                <p className="text-xs text-textSecondary">Phone Number</p>
                <p className="text-sm font-medium text-textPrimary">+1 234 567 890</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="space-y-3">
        <h3 className="font-sora text-sm font-semibold text-textSecondary uppercase tracking-wider px-2">Settings</h3>
        <Card>
          <CardContent className="p-0">
            <button className="w-full flex items-center justify-between p-4 border-b border-gray-50 hover:bg-gray-50 active:bg-gray-100 transition-colors">
              <div className="flex items-center">
                <Settings size={18} className="text-textSecondary mr-3" />
                <span className="text-sm font-medium text-textPrimary">Edit Profile</span>
              </div>
              <ChevronRight size={18} className="text-gray-300" />
            </button>
            <button className="w-full flex items-center p-4 hover:bg-red-50 active:bg-red-100 transition-colors text-error" onClick={() => window.location.reload()}>
              <LogOut size={18} className="mr-3" />
              <span className="text-sm font-medium">Log Out</span>
            </button>
          </CardContent>
        </Card>
      </div>
      
      <div className="text-center pt-4">
        <p className="text-xs text-gray-400">App Version 1.0.0</p>
      </div>
    </div>
  );
}
